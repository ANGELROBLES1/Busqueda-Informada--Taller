"""
In search.py, you will implement generic search algorithms which are called 
by Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
  """
  This class outlines the structure of a search problem, but doesn't implement
  any of the methods (in object-oriented terminology: an abstract class).
  
  You do not need to change anything in this class, ever.
  """
  
  def getStartState(self):
     """
     Returns the start state for the search problem 
     """
     util.raiseNotDefined()
    
  def isGoalState(self, state):
     """
       state: Search state
    
     Returns True if and only if the state is a valid goal state
     """
     util.raiseNotDefined()

  def getSuccessors(self, state):
     """
       state: Search state
     
     For a given state, this should return a list of triples, 
     (successor, action, stepCost), where 'successor' is a 
     successor to the current state, 'action' is the action
     required to get there, and 'stepCost' is the incremental 
     cost of expanding to that successor
     """
     util.raiseNotDefined()

  def getCostOfActions(self, actions):
     """
      actions: A list of actions to take
 
     This method returns the total cost of a particular sequence of actions.  The sequence must
     be composed of legal moves
     """
     util.raiseNotDefined()
           

def tinyMazeSearch(problem):
  """
  Returns a sequence of moves that solves tinyMaze.  For any other
  maze, the sequence of moves will be incorrect, so only use this for tinyMaze
  """
  from game import Directions
  s = Directions.SOUTH
  w = Directions.WEST
  return  [s,s,w,s,w,w,s,w]

def depthFirstSearch(problem):
  """
  Search the deepest nodes in the search tree first [p 85].
  
  Your search algorithm needs to return a list of actions that reaches
  the goal.  Make sure to implement a graph search algorithm [Fig. 3.7].
  
  To get started, you might want to try some of these simple commands to
  understand the search problem that is being passed in:
  
  print "Start:", problem.getStartState()
  print "Is the start a goal?", problem.isGoalState(problem.getStartState())
  print "Start's successors:", problem.getSuccessors(problem.getStartState())
  """

def breadthFirstSearch(problem):
  "Search the shallowest nodes in the search tree first. [p 81]"
      
def uniformCostSearch(problem):
  "Search the node of least total cost first. "
  frontier = util.PriorityQueue()
  startState = problem.getStartState()
  frontier.push((startState, [], 0), 0)   # (estado, camino de acciones, costo acumulado)

  visited = set()

  while not frontier.isEmpty():
    state, actions, cost = frontier.pop()

    if state in visited:
      continue
    visited.add(state)

    if problem.isGoalState(state):
      return actions

    for successor, action, stepCost in problem.getSuccessors(state):
      if successor not in visited:
        newCost = cost + stepCost
        frontier.push((successor, actions + [action], newCost), newCost)

  return None  # No se encontró camino a la meta

def nullHeuristic(state, problem=None):
  """
  A heuristic function estimates the cost from the current state to the nearest
  goal in the provided SearchProblem.  This heuristic is trivial.
  """
  return 0

def aStarSearch(problem, heuristic=nullHeuristic):
  "Search the node that has the lowest combined cost and heuristic first."
  frontier = util.PriorityQueue()
  startState = problem.getStartState() # Obtener el estado inicial del problema
  startPriority = 0 + heuristic(startState, problem)   # f(n) = g(n) + h(n)
  frontier.push((startState, [], 0), startPriority)

  visited = set() 

  while not frontier.isEmpty(): # Mientras haya nodos en la frontera
    state, actions, cost = frontier.pop()

    if state in visited:
      continue
    visited.add(state) # Marcar el estado como visitado

    if problem.isGoalState(state):
      return actions

    for successor, action, stepCost in problem.getSuccessors(state): # Iterar sobre los sucesores del estado actual
      if successor not in visited:
        newCost = cost + stepCost                        # g(n)
        priority = newCost + heuristic(successor, problem)  # f(n) = g(n) + h(n)
        frontier.push((successor, actions + [action], newCost), priority)

  return None  # No se encontro camino a la meta
    
  
# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch